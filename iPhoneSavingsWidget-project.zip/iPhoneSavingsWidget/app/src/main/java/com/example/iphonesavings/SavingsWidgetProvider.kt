package com.example.iphonesavings

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class SavingsWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_ADD_500 -> SavingsStore.change(context, 500)
            ACTION_ADD_1500 -> SavingsStore.change(context, 1500)
            ACTION_SUB_500 -> SavingsStore.change(context, -500)
            ACTION_SUB_1500 -> SavingsStore.change(context, -1500)
        }
        super.onReceive(context, intent)
        if (intent.action in listOf(ACTION_ADD_500, ACTION_ADD_1500, ACTION_SUB_500, ACTION_SUB_1500)) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, SavingsWidgetProvider::class.java))
            onUpdate(context, manager, ids)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> manager.updateAppWidget(id, views(context)) }
    }

    private fun views(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.savings_widget)
        val balance = SavingsStore.getBalance(context)
        val percent = ((balance.toDouble() / SavingsStore.GOAL) * 100).toInt().coerceIn(0, 100)
        val exactPercent = balance.toDouble() / SavingsStore.GOAL * 100.0
        views.setTextViewText(R.id.widget_balance, "${SavingsStore.money(balance)} saved")
        views.setProgressBar(R.id.widget_progress, 100, percent, false)
        views.setTextViewText(R.id.widget_details, String.format("%.1f%% • %s to go", exactPercent, SavingsStore.money((SavingsStore.GOAL - balance).coerceAtLeast(0))))
        views.setOnClickPendingIntent(R.id.add_500, action(context, ACTION_ADD_500, 1))
        views.setOnClickPendingIntent(R.id.add_1500, action(context, ACTION_ADD_1500, 2))
        views.setOnClickPendingIntent(R.id.sub_1500, action(context, ACTION_SUB_1500, 3))
        val open = Intent(context, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(context, 10, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_edit, openPending)
        views.setOnClickPendingIntent(R.id.widget_balance, openPending)
        return views
    }

    private fun action(context: Context, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, SavingsWidgetProvider::class.java).setAction(action)
        return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    companion object {
        const val ACTION_ADD_500 = "com.example.iphonesavings.ADD_500"
        const val ACTION_ADD_1500 = "com.example.iphonesavings.ADD_1500"
        const val ACTION_SUB_500 = "com.example.iphonesavings.SUB_500"
        const val ACTION_SUB_1500 = "com.example.iphonesavings.SUB_1500"
    }
}
