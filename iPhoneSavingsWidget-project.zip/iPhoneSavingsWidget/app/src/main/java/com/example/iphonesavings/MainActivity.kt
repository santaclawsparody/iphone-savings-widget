package com.example.iphonesavings

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var balanceText: TextView
    private lateinit var detailsText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var amountInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(0xFFF5F7F5.toInt())
        }
        root.addView(TextView(this).apply { text = "iPhone 17 Savings"; textSize = 26f; setTextColor(0xFF18221B.toInt()); setTypeface(null, 1) })
        root.addView(TextView(this).apply { text = "Goal: ${SavingsStore.money(SavingsStore.GOAL)}"; textSize = 16f; setPadding(0, dp(6), 0, dp(18)); setTextColor(0xFF4C5A50.toInt()) })
        balanceText = TextView(this).apply { textSize = 30f; setTextColor(0xFF16834A.toInt()); setTypeface(null, 1) }
        root.addView(balanceText)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = android.content.res.ColorStateList.valueOf(0xFF16834A.toInt()) }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(12)).apply { topMargin = dp(12) })
        detailsText = TextView(this).apply { textSize = 15f; setTextColor(0xFF4C5A50.toInt()); setPadding(0, dp(8), 0, dp(22)) }
        root.addView(detailsText)
        amountInput = EditText(this).apply { hint = "Custom amount in JMD"; inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }
        root.addView(amountInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        root.addView(button("Add custom amount") { changeCustom(true) })
        root.addView(button("Subtract custom amount") { changeCustom(false) })
        root.addView(button("Add J$1,500") { SavingsStore.change(this, 1500); refresh() })
        root.addView(button("Subtract J$1,500") { SavingsStore.change(this, -1500); refresh() })
        root.addView(button("Reset to J$22,000") { SavingsStore.setBalance(this, SavingsStore.STARTING_BALANCE); refresh() })
        root.addView(TextView(this).apply {
            text = "Your balance is saved on this phone. Add the widget by long-pressing an empty area of your home screen, choosing Widgets, then finding iPhone Savings."
            textSize = 14f; setTextColor(0xFF4C5A50.toInt()); setPadding(0, dp(20), 0, 0)
        })
        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); if (::balanceText.isInitialized) refresh() }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(5) }
    }

    private fun changeCustom(add: Boolean) {
        val amount = amountInput.text.toString().toLongOrNull()
        if (amount == null || amount <= 0) { amountInput.error = "Enter an amount greater than zero"; return }
        SavingsStore.change(this, if (add) amount else -amount)
        amountInput.text.clear()
        refresh()
    }

    private fun refresh() {
        val balance = SavingsStore.getBalance(this)
        val percent = (balance.toDouble() / SavingsStore.GOAL * 100).coerceIn(0.0, 100.0)
        balanceText.text = "${SavingsStore.money(balance)} saved"
        progress.progress = percent.toInt()
        detailsText.text = String.format("%.1f%% complete\n%s remaining", percent, SavingsStore.money((SavingsStore.GOAL - balance).coerceAtLeast(0)))
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, SavingsWidgetProvider::class.java))
        if (ids.isNotEmpty()) SavingsWidgetProvider().onUpdate(this, manager, ids)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
