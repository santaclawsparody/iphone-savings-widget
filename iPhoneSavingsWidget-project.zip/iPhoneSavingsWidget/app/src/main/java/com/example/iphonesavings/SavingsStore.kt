package com.example.iphonesavings

import android.content.Context

object SavingsStore {
    private const val PREFS = "iphone_savings"
    private const val BALANCE = "balance"
    const val GOAL = 135000L
    const val STARTING_BALANCE = 22000L

    fun getBalance(context: Context): Long = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getLong(BALANCE, STARTING_BALANCE)

    fun setBalance(context: Context, value: Long) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(BALANCE, value.coerceAtLeast(0L)).apply()
    }

    fun change(context: Context, delta: Long) {
        setBalance(context, (getBalance(context) + delta).coerceAtLeast(0L))
    }

    fun money(value: Long): String = "J$" + String.format("%,d", value)
}
