# iPhone Savings Widget (Android)

A native Android home-screen widget for tracking an iPhone 17 savings goal.

## Defaults
- Starting balance: J$22,000
- Goal: J$135,000
- Widget controls: +J$500, +J$1,500, −J$1,500
- App controls: custom add/subtract amounts, +/− J$1,500, reset to starting balance
- Persistence: Android SharedPreferences, stored locally on the phone

## Build without owning a computer (GitHub Actions)
This project includes `.github/workflows/build-apk.yml`, which can compile a debug APK on GitHub's cloud runners. You need a GitHub account and must put the project files into a GitHub repository. GitHub's mobile website/app can be awkward for uploading an entire folder tree, so this step may be easier in a mobile browser with GitHub's web editor or with help from someone you trust. Do not share your GitHub password or recovery codes.

After the files are in your repository:
1. Open the repository on GitHub.
2. Tap **Actions** and select **Build Android APK**.
3. Tap **Run workflow** (if prompted, select the `main` branch).
4. Wait for the run to finish successfully.
5. Open the completed run and find **Artifacts** near the bottom.
6. Download `iPhone-Savings-debug-apk`; extract the downloaded ZIP to get `app-debug.apk`.
7. Open the APK on your Samsung A26 and allow installation from that source if Android asks. Only install the APK you built from your own repository.
8. Open **iPhone Savings**, then long-press an empty home-screen area → **Widgets** → **iPhone Savings** and add it.

The first GitHub setup still requires uploading the project source; this workflow automates the compilation, not the initial upload. A debug APK is for personal installation and is not a Play Store release.

## Build with Android Studio (computer)
1. Open this folder (`iPhoneSavingsWidget`) in Android Studio.
2. Let Gradle sync and install any requested Android SDK platform (API 35).
3. Connect the Galaxy A26 to the computer with USB debugging enabled, or use Android Studio's device pairing.
4. Press Run to install the app on the phone.
5. On the phone, long-press an empty part of the home screen → Widgets → iPhone Savings → add the widget.

## Notes
- All savings data stays locally on the device; there is no account or cloud sync.
- Widget buttons adjust the balance immediately. Tap the balance or edit button to open the app.
- Android may theme widgets differently depending on One UI version.
- The widget's visible controls are +500, +1500, and −1500. The app has custom amount controls for both adding and subtracting.
